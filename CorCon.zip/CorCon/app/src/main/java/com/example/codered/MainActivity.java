package com.example.codered;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.menu.ShowableListMenu;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Context context = getApplicationContext();
    public void btnClick(View view){
        EditText dollarAmount =(EditText) findViewById(R.id.dollarAmount);
        String dollars = dollarAmount.getText().toString();
        Double doubleDollars= Double.parseDouble(dollars);
        Double doubleInr = 76.68 * doubleDollars;
        String toasttext = "=" + doubleInr.toString() + "$";
        Toast.makeText(context, toasttext,Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
